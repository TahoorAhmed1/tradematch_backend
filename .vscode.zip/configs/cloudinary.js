const cloudinary = require("cloudinary").v2;

cloudinary.config({
  cloud_name: "dttbpzogu",
  api_key: "328281745543463",
  api_secret: "OGTsra7D6jLnbK0_ay1ZQAJ25kg",
});

module.exports = cloudinary;
